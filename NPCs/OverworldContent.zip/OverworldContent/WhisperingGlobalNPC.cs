﻿using WhisperingDeath.Items.Accesories;
using WhisperingDeath.Items;
using WhisperingDeath.Projectiles;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace WhisperingDeath.NPCs
{
    public class WhisperingGlobalNPC : GlobalNPC
    {
        public override bool InstancePerEntity => true;


        public bool NightsCurse;
        public bool vFlames;
        public bool NanoInject;

        public override void ResetEffects(NPC npc)
        {
            NightsCurse = false;
            vFlames = false;
            NanoInject = false;
        }
        public override void UpdateLifeRegen(NPC npc, ref int damage)
        {
            if (NightsCurse)
            {
                if (npc.lifeRegen > 0)
                {
                    npc.lifeRegen = 0;
                }
                npc.lifeRegen -= 16;
                if (damage < 2)
                {
                    damage = 2;
                }
            }

            if (vFlames)
            {
                if (npc.lifeRegen > 0)
                {
                    npc.lifeRegen = 0;
                }
                npc.lifeRegen -= 50;
                if (damage < 10)
                {
                    damage = 10;
                }
            }

            if (NanoInject)
            {
                if (npc.lifeRegen > 0)
                {
                    npc.lifeRegen = 0;
                }
                npc.lifeRegen -= 50;
                if (damage < 5)
                {
                    damage = 5;
                }
            }

        }

        public override void EditSpawnRate(Player player, ref int spawnRate, ref int maxSpawns)
        {
            if (NPC.AnyNPCs(ModContent.NPCType<Bosses.Aakhotep>()))
            {
                maxSpawns *= 0;
                spawnRate *= 20;
            }
        }

        public override void SetupShop(int type, Chest shop, ref int nextSlot)
        {
            if (type == NPCID.SkeletonMerchant)
            {
                if (Main.moonPhase < 1)
                {
                    shop.item[nextSlot].SetDefaults(ItemID.BoneSword);
                    shop.item[nextSlot].shopCustomPrice = 15400;
                    nextSlot++;
                }

                else if (Main.moonPhase < 3)
                {
                    shop.item[nextSlot].SetDefaults(ItemID.BoneSword);
                    shop.item[nextSlot].shopCustomPrice = 15400;
                    nextSlot++;
                }

                else if (Main.moonPhase < 5)
                {
                    shop.item[nextSlot].SetDefaults(ItemID.BoneSword);
                    shop.item[nextSlot].shopCustomPrice = 15400;
                    nextSlot++;
                }

                else if (Main.moonPhase < 7)
                {
                    shop.item[nextSlot].SetDefaults(ItemID.BoneSword);
                    shop.item[nextSlot].shopCustomPrice = 15400;
                    nextSlot++;
                }

                else if (NPC.downedBoss3)
                {
                    shop.item[nextSlot].SetDefaults(ItemID.Bone);
                    shop.item[nextSlot].shopCustomPrice = 112;
                    nextSlot++;
                }
            }

            if (type == NPCID.WitchDoctor)
            {
                if (NPC.downedPlantBoss)
                {
                    shop.item[nextSlot].SetDefaults(ModContent.ItemType<TribalEarring>());
                    shop.item[nextSlot].shopCustomPrice = 750000;
                    nextSlot++;
                }
            }

            if (type == NPCID.DyeTrader)
            {
                shop.item[nextSlot].SetDefaults(ItemID.Leather);
                shop.item[nextSlot].shopCustomPrice = 25;
                nextSlot++;
            }
        }

        public override bool PreNPCLoot(NPC npc)
        {
            if (!NPC.downedPlantBoss && npc.type == NPCID.Plantera)
            {
                Main.NewText("The icy Tundra is empowered...", Color.LightCyan);
            }

            if (!NPC.downedBoss1 && npc.type == NPCID.EyeofCthulhu)
            {
                Main.NewText("The voidic depths stir...", Color.DarkSlateBlue);
            }
            return true;
        }
    }
}  
